===============================================================
		DARK MODE PIXELMON REFORGED 1.16	
---------------------------------------------------------------

Minecraft version: 1.16.5
Pixelmon version: 9.1.3 (Newer versions could not properly work)

Play along Default Dark Mode Resourcepack for a complete Dark Theme 
experience: 
https://www.curseforge.com/minecraft/texture-packs/default-dark-mode

This Resourcepack is an update version of: 
Dark Theme for Pixelmon Reforged FROM iLisov
https://www.planetminecraft.com/texture-pack/dark-theme-for-pixelmon-reforged/

Thanks to iLisov for his incredible original work, to the Pixelmon Mod Dev Team
for creating the unique experience that is mixing Minecraft with Pokémon.

---------------------------------------------------------------

INSTALLATION GUIDE

1. Place the zip file in the resourcepack folder of your Minecraft Saves.

2. Launch Minecraft and go to Options/Resourcepacks and select this resourcepack from
the left column.

---------------------------------------------------------------